secret_word = "giraffe"
guess = ""
guess_count = 0
guess_limit = 5
out_of_guesses = False

while guess != secret_word and not out_of_guesses:
    if guess_count < guess_limit:
       guess = input("Guess a guess: ")
    guess_count += 1
else:
    out_of_guesses = False

if out_of_guesses:
 print ("out of guesses, YOU LOSE")
else:
    print ("YOU WIN")